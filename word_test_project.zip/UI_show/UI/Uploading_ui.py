# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Uploading.ui'
##
## Created by: Qt User Interface Compiler version 6.8.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QWidget)

class Ui_uploading_windows(object):
    def setupUi(self, uploading_windows):
        if not uploading_windows.objectName():
            uploading_windows.setObjectName(u"uploading_windows")
        uploading_windows.resize(1047, 639)
        self.label = QLabel(uploading_windows)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 40, 31, 21))
        font = QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label_2 = QLabel(uploading_windows)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(0, 70, 31, 21))
        self.label_2.setFont(font)
        self.label_3 = QLabel(uploading_windows)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(0, 100, 31, 21))
        self.label_3.setFont(font)
        self.label_4 = QLabel(uploading_windows)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(0, 130, 31, 21))
        self.label_4.setFont(font)
        self.label_5 = QLabel(uploading_windows)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(0, 160, 31, 16))
        self.label_5.setFont(font)
        self.label_6 = QLabel(uploading_windows)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(0, 190, 31, 16))
        self.label_6.setFont(font)
        self.label_7 = QLabel(uploading_windows)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(0, 220, 31, 16))
        self.label_7.setFont(font)
        self.label_8 = QLabel(uploading_windows)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(0, 250, 31, 16))
        self.label_8.setFont(font)
        self.label_9 = QLabel(uploading_windows)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(0, 280, 31, 21))
        self.label_9.setFont(font)
        self.label_10 = QLabel(uploading_windows)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(0, 310, 31, 21))
        self.label_10.setFont(font)
        self.label_11 = QLabel(uploading_windows)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(0, 340, 31, 21))
        self.label_11.setFont(font)
        self.label_12 = QLabel(uploading_windows)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(0, 370, 31, 21))
        self.label_12.setFont(font)
        self.label_13 = QLabel(uploading_windows)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(0, 400, 31, 21))
        self.label_13.setFont(font)
        self.label_14 = QLabel(uploading_windows)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(0, 520, 31, 21))
        self.label_14.setFont(font)
        self.label_15 = QLabel(uploading_windows)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setGeometry(QRect(0, 490, 31, 21))
        self.label_15.setFont(font)
        self.label_16 = QLabel(uploading_windows)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setGeometry(QRect(0, 460, 31, 21))
        self.label_16.setFont(font)
        self.label_17 = QLabel(uploading_windows)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setGeometry(QRect(0, 430, 31, 21))
        self.label_17.setFont(font)
        self.label_18 = QLabel(uploading_windows)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setGeometry(QRect(0, 550, 31, 21))
        self.label_18.setFont(font)
        self.label_19 = QLabel(uploading_windows)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setGeometry(QRect(0, 580, 31, 21))
        self.label_19.setFont(font)
        self.label_20 = QLabel(uploading_windows)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setGeometry(QRect(0, 610, 31, 21))
        self.label_20.setFont(font)
        self.label_41 = QLabel(uploading_windows)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setGeometry(QRect(50, 10, 41, 21))
        self.label_41.setFont(font)
        self.label_42 = QLabel(uploading_windows)
        self.label_42.setObjectName(u"label_42")
        self.label_42.setGeometry(QRect(210, 10, 21, 20))
        self.label_42.setFont(font)
        self.label_21 = QLabel(uploading_windows)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(440, 550, 31, 21))
        self.label_21.setFont(font)
        self.label_22 = QLabel(uploading_windows)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(440, 310, 31, 21))
        self.label_22.setFont(font)
        self.label_23 = QLabel(uploading_windows)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(440, 460, 31, 21))
        self.label_23.setFont(font)
        self.label_24 = QLabel(uploading_windows)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(440, 490, 31, 21))
        self.label_24.setFont(font)
        self.label_25 = QLabel(uploading_windows)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(440, 340, 31, 21))
        self.label_25.setFont(font)
        self.label_26 = QLabel(uploading_windows)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(440, 430, 31, 21))
        self.label_26.setFont(font)
        self.label_27 = QLabel(uploading_windows)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(440, 190, 31, 16))
        self.label_27.setFont(font)
        self.label_28 = QLabel(uploading_windows)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(440, 100, 31, 21))
        self.label_28.setFont(font)
        self.label_43 = QLabel(uploading_windows)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setGeometry(QRect(650, 10, 21, 20))
        self.label_43.setFont(font)
        self.label_29 = QLabel(uploading_windows)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(440, 280, 31, 21))
        self.label_29.setFont(font)
        self.label_30 = QLabel(uploading_windows)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(440, 160, 31, 16))
        self.label_30.setFont(font)
        self.label_31 = QLabel(uploading_windows)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(440, 130, 31, 21))
        self.label_31.setFont(font)
        self.label_32 = QLabel(uploading_windows)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setGeometry(QRect(440, 520, 31, 21))
        self.label_32.setFont(font)
        self.label_44 = QLabel(uploading_windows)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setGeometry(QRect(500, 10, 41, 21))
        self.label_44.setFont(font)
        self.label_33 = QLabel(uploading_windows)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setGeometry(QRect(440, 40, 31, 21))
        self.label_33.setFont(font)
        self.label_34 = QLabel(uploading_windows)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setGeometry(QRect(440, 370, 31, 21))
        self.label_34.setFont(font)
        self.label_35 = QLabel(uploading_windows)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setGeometry(QRect(440, 250, 31, 16))
        self.label_35.setFont(font)
        self.label_36 = QLabel(uploading_windows)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setGeometry(QRect(440, 400, 31, 21))
        self.label_36.setFont(font)
        self.label_37 = QLabel(uploading_windows)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setGeometry(QRect(440, 220, 31, 16))
        self.label_37.setFont(font)
        self.label_38 = QLabel(uploading_windows)
        self.label_38.setObjectName(u"label_38")
        self.label_38.setGeometry(QRect(440, 580, 31, 21))
        self.label_38.setFont(font)
        self.label_39 = QLabel(uploading_windows)
        self.label_39.setObjectName(u"label_39")
        self.label_39.setGeometry(QRect(440, 610, 31, 21))
        self.label_39.setFont(font)
        self.label_40 = QLabel(uploading_windows)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setGeometry(QRect(440, 70, 31, 21))
        self.label_40.setFont(font)
        self.label_125 = QLabel(uploading_windows)
        self.label_125.setObjectName(u"label_125")
        self.label_125.setGeometry(QRect(140, 40, 31, 21))
        self.label_125.setFont(font)
        self.label_126 = QLabel(uploading_windows)
        self.label_126.setObjectName(u"label_126")
        self.label_126.setGeometry(QRect(140, 70, 31, 21))
        self.label_126.setFont(font)
        self.label_127 = QLabel(uploading_windows)
        self.label_127.setObjectName(u"label_127")
        self.label_127.setGeometry(QRect(140, 100, 31, 21))
        self.label_127.setFont(font)
        self.label_128 = QLabel(uploading_windows)
        self.label_128.setObjectName(u"label_128")
        self.label_128.setGeometry(QRect(140, 130, 31, 21))
        self.label_128.setFont(font)
        self.label_129 = QLabel(uploading_windows)
        self.label_129.setObjectName(u"label_129")
        self.label_129.setGeometry(QRect(140, 160, 31, 21))
        self.label_129.setFont(font)
        self.label_130 = QLabel(uploading_windows)
        self.label_130.setObjectName(u"label_130")
        self.label_130.setGeometry(QRect(140, 190, 31, 21))
        self.label_130.setFont(font)
        self.label_131 = QLabel(uploading_windows)
        self.label_131.setObjectName(u"label_131")
        self.label_131.setGeometry(QRect(140, 220, 31, 21))
        self.label_131.setFont(font)
        self.label_132 = QLabel(uploading_windows)
        self.label_132.setObjectName(u"label_132")
        self.label_132.setGeometry(QRect(140, 250, 31, 21))
        self.label_132.setFont(font)
        self.label_133 = QLabel(uploading_windows)
        self.label_133.setObjectName(u"label_133")
        self.label_133.setGeometry(QRect(140, 280, 31, 21))
        self.label_133.setFont(font)
        self.label_134 = QLabel(uploading_windows)
        self.label_134.setObjectName(u"label_134")
        self.label_134.setGeometry(QRect(140, 310, 31, 21))
        self.label_134.setFont(font)
        self.label_135 = QLabel(uploading_windows)
        self.label_135.setObjectName(u"label_135")
        self.label_135.setGeometry(QRect(140, 460, 31, 21))
        self.label_135.setFont(font)
        self.label_136 = QLabel(uploading_windows)
        self.label_136.setObjectName(u"label_136")
        self.label_136.setGeometry(QRect(140, 430, 31, 21))
        self.label_136.setFont(font)
        self.label_137 = QLabel(uploading_windows)
        self.label_137.setObjectName(u"label_137")
        self.label_137.setGeometry(QRect(140, 400, 31, 21))
        self.label_137.setFont(font)
        self.label_138 = QLabel(uploading_windows)
        self.label_138.setObjectName(u"label_138")
        self.label_138.setGeometry(QRect(140, 340, 31, 21))
        self.label_138.setFont(font)
        self.label_139 = QLabel(uploading_windows)
        self.label_139.setObjectName(u"label_139")
        self.label_139.setGeometry(QRect(140, 370, 31, 21))
        self.label_139.setFont(font)
        self.label_140 = QLabel(uploading_windows)
        self.label_140.setObjectName(u"label_140")
        self.label_140.setGeometry(QRect(140, 490, 31, 21))
        self.label_140.setFont(font)
        self.label_141 = QLabel(uploading_windows)
        self.label_141.setObjectName(u"label_141")
        self.label_141.setGeometry(QRect(140, 580, 31, 21))
        self.label_141.setFont(font)
        self.label_142 = QLabel(uploading_windows)
        self.label_142.setObjectName(u"label_142")
        self.label_142.setGeometry(QRect(140, 550, 31, 21))
        self.label_142.setFont(font)
        self.label_143 = QLabel(uploading_windows)
        self.label_143.setObjectName(u"label_143")
        self.label_143.setGeometry(QRect(140, 520, 31, 21))
        self.label_143.setFont(font)
        self.label_144 = QLabel(uploading_windows)
        self.label_144.setObjectName(u"label_144")
        self.label_144.setGeometry(QRect(140, 610, 31, 21))
        self.label_144.setFont(font)
        self.label_145 = QLabel(uploading_windows)
        self.label_145.setObjectName(u"label_145")
        self.label_145.setGeometry(QRect(580, 310, 31, 21))
        self.label_145.setFont(font)
        self.label_146 = QLabel(uploading_windows)
        self.label_146.setObjectName(u"label_146")
        self.label_146.setGeometry(QRect(580, 460, 31, 21))
        self.label_146.setFont(font)
        self.label_147 = QLabel(uploading_windows)
        self.label_147.setObjectName(u"label_147")
        self.label_147.setGeometry(QRect(580, 610, 31, 21))
        self.label_147.setFont(font)
        self.label_148 = QLabel(uploading_windows)
        self.label_148.setObjectName(u"label_148")
        self.label_148.setGeometry(QRect(580, 370, 31, 21))
        self.label_148.setFont(font)
        self.label_149 = QLabel(uploading_windows)
        self.label_149.setObjectName(u"label_149")
        self.label_149.setGeometry(QRect(580, 40, 31, 21))
        self.label_149.setFont(font)
        self.label_150 = QLabel(uploading_windows)
        self.label_150.setObjectName(u"label_150")
        self.label_150.setGeometry(QRect(580, 580, 31, 21))
        self.label_150.setFont(font)
        self.label_151 = QLabel(uploading_windows)
        self.label_151.setObjectName(u"label_151")
        self.label_151.setGeometry(QRect(580, 430, 31, 21))
        self.label_151.setFont(font)
        self.label_152 = QLabel(uploading_windows)
        self.label_152.setObjectName(u"label_152")
        self.label_152.setGeometry(QRect(580, 400, 31, 21))
        self.label_152.setFont(font)
        self.label_153 = QLabel(uploading_windows)
        self.label_153.setObjectName(u"label_153")
        self.label_153.setGeometry(QRect(580, 70, 31, 21))
        self.label_153.setFont(font)
        self.label_154 = QLabel(uploading_windows)
        self.label_154.setObjectName(u"label_154")
        self.label_154.setGeometry(QRect(580, 550, 31, 21))
        self.label_154.setFont(font)
        self.label_155 = QLabel(uploading_windows)
        self.label_155.setObjectName(u"label_155")
        self.label_155.setGeometry(QRect(580, 220, 31, 21))
        self.label_155.setFont(font)
        self.label_156 = QLabel(uploading_windows)
        self.label_156.setObjectName(u"label_156")
        self.label_156.setGeometry(QRect(580, 190, 31, 21))
        self.label_156.setFont(font)
        self.label_157 = QLabel(uploading_windows)
        self.label_157.setObjectName(u"label_157")
        self.label_157.setGeometry(QRect(580, 280, 31, 21))
        self.label_157.setFont(font)
        self.label_158 = QLabel(uploading_windows)
        self.label_158.setObjectName(u"label_158")
        self.label_158.setGeometry(QRect(580, 160, 31, 21))
        self.label_158.setFont(font)
        self.label_159 = QLabel(uploading_windows)
        self.label_159.setObjectName(u"label_159")
        self.label_159.setGeometry(QRect(580, 100, 31, 21))
        self.label_159.setFont(font)
        self.label_160 = QLabel(uploading_windows)
        self.label_160.setObjectName(u"label_160")
        self.label_160.setGeometry(QRect(580, 130, 31, 21))
        self.label_160.setFont(font)
        self.label_161 = QLabel(uploading_windows)
        self.label_161.setObjectName(u"label_161")
        self.label_161.setGeometry(QRect(580, 490, 31, 21))
        self.label_161.setFont(font)
        self.label_162 = QLabel(uploading_windows)
        self.label_162.setObjectName(u"label_162")
        self.label_162.setGeometry(QRect(580, 340, 31, 21))
        self.label_162.setFont(font)
        self.label_163 = QLabel(uploading_windows)
        self.label_163.setObjectName(u"label_163")
        self.label_163.setGeometry(QRect(580, 250, 31, 21))
        self.label_163.setFont(font)
        self.label_164 = QLabel(uploading_windows)
        self.label_164.setObjectName(u"label_164")
        self.label_164.setGeometry(QRect(580, 520, 31, 21))
        self.label_164.setFont(font)
        self.upload = QPushButton(uploading_windows)
        self.upload.setObjectName(u"upload")
        self.upload.setGeometry(QRect(870, 490, 171, 61))
        font1 = QFont()
        font1.setPointSize(20)
        self.upload.setFont(font1)
        self.Subject_select = QComboBox(uploading_windows)
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.addItem("")
        self.Subject_select.setObjectName(u"Subject_select")
        self.Subject_select.setGeometry(QRect(870, 410, 171, 41))
        font2 = QFont()
        font2.setPointSize(16)
        self.Subject_select.setFont(font2)
        self.label_45 = QLabel(uploading_windows)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setGeometry(QRect(890, 370, 111, 31))
        self.label_45.setFont(font2)
        self.Word_1 = QLineEdit(uploading_windows)
        self.Word_1.setObjectName(u"Word_1")
        self.Word_1.setGeometry(QRect(30, 39, 101, 21))
        self.Word_1.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_2 = QLineEdit(uploading_windows)
        self.Word_2.setObjectName(u"Word_2")
        self.Word_2.setGeometry(QRect(30, 70, 101, 21))
        self.Word_2.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_3 = QLineEdit(uploading_windows)
        self.Word_3.setObjectName(u"Word_3")
        self.Word_3.setGeometry(QRect(30, 100, 101, 21))
        self.Word_3.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_4 = QLineEdit(uploading_windows)
        self.Word_4.setObjectName(u"Word_4")
        self.Word_4.setGeometry(QRect(30, 130, 101, 21))
        self.Word_4.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_5 = QLineEdit(uploading_windows)
        self.Word_5.setObjectName(u"Word_5")
        self.Word_5.setGeometry(QRect(30, 160, 101, 21))
        self.Word_5.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_6 = QLineEdit(uploading_windows)
        self.Word_6.setObjectName(u"Word_6")
        self.Word_6.setGeometry(QRect(30, 190, 101, 21))
        self.Word_6.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_7 = QLineEdit(uploading_windows)
        self.Word_7.setObjectName(u"Word_7")
        self.Word_7.setGeometry(QRect(30, 220, 101, 21))
        self.Word_7.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_8 = QLineEdit(uploading_windows)
        self.Word_8.setObjectName(u"Word_8")
        self.Word_8.setGeometry(QRect(30, 250, 101, 21))
        self.Word_8.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_9 = QLineEdit(uploading_windows)
        self.Word_9.setObjectName(u"Word_9")
        self.Word_9.setGeometry(QRect(30, 280, 101, 21))
        self.Word_9.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_10 = QLineEdit(uploading_windows)
        self.Word_10.setObjectName(u"Word_10")
        self.Word_10.setGeometry(QRect(30, 310, 101, 21))
        self.Word_10.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_11 = QLineEdit(uploading_windows)
        self.Word_11.setObjectName(u"Word_11")
        self.Word_11.setGeometry(QRect(30, 340, 101, 21))
        self.Word_11.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_12 = QLineEdit(uploading_windows)
        self.Word_12.setObjectName(u"Word_12")
        self.Word_12.setGeometry(QRect(30, 370, 101, 21))
        self.Word_12.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_13 = QLineEdit(uploading_windows)
        self.Word_13.setObjectName(u"Word_13")
        self.Word_13.setGeometry(QRect(30, 400, 101, 21))
        self.Word_13.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_14 = QLineEdit(uploading_windows)
        self.Word_14.setObjectName(u"Word_14")
        self.Word_14.setGeometry(QRect(30, 430, 101, 21))
        self.Word_14.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_15 = QLineEdit(uploading_windows)
        self.Word_15.setObjectName(u"Word_15")
        self.Word_15.setGeometry(QRect(30, 460, 101, 21))
        self.Word_15.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_16 = QLineEdit(uploading_windows)
        self.Word_16.setObjectName(u"Word_16")
        self.Word_16.setGeometry(QRect(30, 490, 101, 21))
        self.Word_16.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_17 = QLineEdit(uploading_windows)
        self.Word_17.setObjectName(u"Word_17")
        self.Word_17.setGeometry(QRect(30, 520, 101, 21))
        self.Word_17.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_18 = QLineEdit(uploading_windows)
        self.Word_18.setObjectName(u"Word_18")
        self.Word_18.setGeometry(QRect(30, 550, 101, 21))
        self.Word_18.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_19 = QLineEdit(uploading_windows)
        self.Word_19.setObjectName(u"Word_19")
        self.Word_19.setGeometry(QRect(30, 580, 101, 21))
        self.Word_19.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_20 = QLineEdit(uploading_windows)
        self.Word_20.setObjectName(u"Word_20")
        self.Word_20.setGeometry(QRect(30, 610, 101, 21))
        self.Word_20.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_1 = QLineEdit(uploading_windows)
        self.Meaning_1.setObjectName(u"Meaning_1")
        self.Meaning_1.setGeometry(QRect(170, 40, 251, 21))
        self.Meaning_1.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_2 = QLineEdit(uploading_windows)
        self.Meaning_2.setObjectName(u"Meaning_2")
        self.Meaning_2.setGeometry(QRect(170, 70, 251, 21))
        self.Meaning_2.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_3 = QLineEdit(uploading_windows)
        self.Meaning_3.setObjectName(u"Meaning_3")
        self.Meaning_3.setGeometry(QRect(170, 100, 251, 21))
        self.Meaning_3.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_4 = QLineEdit(uploading_windows)
        self.Meaning_4.setObjectName(u"Meaning_4")
        self.Meaning_4.setGeometry(QRect(170, 130, 251, 21))
        self.Meaning_4.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_5 = QLineEdit(uploading_windows)
        self.Meaning_5.setObjectName(u"Meaning_5")
        self.Meaning_5.setGeometry(QRect(170, 160, 251, 21))
        self.Meaning_5.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_6 = QLineEdit(uploading_windows)
        self.Meaning_6.setObjectName(u"Meaning_6")
        self.Meaning_6.setGeometry(QRect(170, 190, 251, 21))
        self.Meaning_6.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_7 = QLineEdit(uploading_windows)
        self.Meaning_7.setObjectName(u"Meaning_7")
        self.Meaning_7.setGeometry(QRect(170, 220, 251, 21))
        self.Meaning_7.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_8 = QLineEdit(uploading_windows)
        self.Meaning_8.setObjectName(u"Meaning_8")
        self.Meaning_8.setGeometry(QRect(170, 250, 251, 21))
        self.Meaning_8.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_9 = QLineEdit(uploading_windows)
        self.Meaning_9.setObjectName(u"Meaning_9")
        self.Meaning_9.setGeometry(QRect(170, 280, 251, 21))
        self.Meaning_9.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_10 = QLineEdit(uploading_windows)
        self.Meaning_10.setObjectName(u"Meaning_10")
        self.Meaning_10.setGeometry(QRect(170, 310, 251, 21))
        self.Meaning_10.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_11 = QLineEdit(uploading_windows)
        self.Meaning_11.setObjectName(u"Meaning_11")
        self.Meaning_11.setGeometry(QRect(170, 340, 251, 21))
        self.Meaning_11.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_12 = QLineEdit(uploading_windows)
        self.Meaning_12.setObjectName(u"Meaning_12")
        self.Meaning_12.setGeometry(QRect(170, 370, 251, 21))
        self.Meaning_12.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_13 = QLineEdit(uploading_windows)
        self.Meaning_13.setObjectName(u"Meaning_13")
        self.Meaning_13.setGeometry(QRect(170, 400, 251, 21))
        self.Meaning_13.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_14 = QLineEdit(uploading_windows)
        self.Meaning_14.setObjectName(u"Meaning_14")
        self.Meaning_14.setGeometry(QRect(170, 430, 251, 21))
        self.Meaning_14.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_15 = QLineEdit(uploading_windows)
        self.Meaning_15.setObjectName(u"Meaning_15")
        self.Meaning_15.setGeometry(QRect(170, 460, 251, 21))
        self.Meaning_15.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_16 = QLineEdit(uploading_windows)
        self.Meaning_16.setObjectName(u"Meaning_16")
        self.Meaning_16.setGeometry(QRect(170, 490, 251, 21))
        self.Meaning_16.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_17 = QLineEdit(uploading_windows)
        self.Meaning_17.setObjectName(u"Meaning_17")
        self.Meaning_17.setGeometry(QRect(170, 520, 251, 21))
        self.Meaning_17.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_18 = QLineEdit(uploading_windows)
        self.Meaning_18.setObjectName(u"Meaning_18")
        self.Meaning_18.setGeometry(QRect(170, 550, 251, 21))
        self.Meaning_18.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_19 = QLineEdit(uploading_windows)
        self.Meaning_19.setObjectName(u"Meaning_19")
        self.Meaning_19.setGeometry(QRect(170, 580, 251, 21))
        self.Meaning_19.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_20 = QLineEdit(uploading_windows)
        self.Meaning_20.setObjectName(u"Meaning_20")
        self.Meaning_20.setGeometry(QRect(170, 610, 251, 21))
        self.Meaning_20.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_21 = QLineEdit(uploading_windows)
        self.Meaning_21.setObjectName(u"Meaning_21")
        self.Meaning_21.setGeometry(QRect(610, 41, 251, 21))
        self.Meaning_21.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_21 = QLineEdit(uploading_windows)
        self.Word_21.setObjectName(u"Word_21")
        self.Word_21.setGeometry(QRect(470, 40, 101, 21))
        self.Word_21.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_22 = QLineEdit(uploading_windows)
        self.Word_22.setObjectName(u"Word_22")
        self.Word_22.setGeometry(QRect(470, 69, 101, 21))
        self.Word_22.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_22 = QLineEdit(uploading_windows)
        self.Meaning_22.setObjectName(u"Meaning_22")
        self.Meaning_22.setGeometry(QRect(610, 70, 251, 21))
        self.Meaning_22.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_23 = QLineEdit(uploading_windows)
        self.Word_23.setObjectName(u"Word_23")
        self.Word_23.setGeometry(QRect(470, 100, 101, 21))
        self.Word_23.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_23 = QLineEdit(uploading_windows)
        self.Meaning_23.setObjectName(u"Meaning_23")
        self.Meaning_23.setGeometry(QRect(610, 101, 251, 21))
        self.Meaning_23.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_24 = QLineEdit(uploading_windows)
        self.Word_24.setObjectName(u"Word_24")
        self.Word_24.setGeometry(QRect(470, 129, 101, 21))
        self.Word_24.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_24 = QLineEdit(uploading_windows)
        self.Meaning_24.setObjectName(u"Meaning_24")
        self.Meaning_24.setGeometry(QRect(610, 130, 251, 21))
        self.Meaning_24.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_25 = QLineEdit(uploading_windows)
        self.Meaning_25.setObjectName(u"Meaning_25")
        self.Meaning_25.setGeometry(QRect(610, 161, 251, 21))
        self.Meaning_25.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_25 = QLineEdit(uploading_windows)
        self.Word_25.setObjectName(u"Word_25")
        self.Word_25.setGeometry(QRect(470, 160, 101, 21))
        self.Word_25.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_26 = QLineEdit(uploading_windows)
        self.Word_26.setObjectName(u"Word_26")
        self.Word_26.setGeometry(QRect(470, 190, 101, 21))
        self.Word_26.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_26 = QLineEdit(uploading_windows)
        self.Meaning_26.setObjectName(u"Meaning_26")
        self.Meaning_26.setGeometry(QRect(610, 191, 251, 21))
        self.Meaning_26.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_27 = QLineEdit(uploading_windows)
        self.Word_27.setObjectName(u"Word_27")
        self.Word_27.setGeometry(QRect(470, 219, 101, 21))
        self.Word_27.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_27 = QLineEdit(uploading_windows)
        self.Meaning_27.setObjectName(u"Meaning_27")
        self.Meaning_27.setGeometry(QRect(610, 220, 251, 21))
        self.Meaning_27.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_28 = QLineEdit(uploading_windows)
        self.Meaning_28.setObjectName(u"Meaning_28")
        self.Meaning_28.setGeometry(QRect(610, 251, 251, 21))
        self.Meaning_28.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_28 = QLineEdit(uploading_windows)
        self.Word_28.setObjectName(u"Word_28")
        self.Word_28.setGeometry(QRect(470, 250, 101, 21))
        self.Word_28.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_29 = QLineEdit(uploading_windows)
        self.Meaning_29.setObjectName(u"Meaning_29")
        self.Meaning_29.setGeometry(QRect(610, 281, 251, 21))
        self.Meaning_29.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_29 = QLineEdit(uploading_windows)
        self.Word_29.setObjectName(u"Word_29")
        self.Word_29.setGeometry(QRect(470, 280, 101, 21))
        self.Word_29.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_30 = QLineEdit(uploading_windows)
        self.Meaning_30.setObjectName(u"Meaning_30")
        self.Meaning_30.setGeometry(QRect(610, 311, 251, 21))
        self.Meaning_30.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_30 = QLineEdit(uploading_windows)
        self.Word_30.setObjectName(u"Word_30")
        self.Word_30.setGeometry(QRect(470, 310, 101, 21))
        self.Word_30.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_31 = QLineEdit(uploading_windows)
        self.Word_31.setObjectName(u"Word_31")
        self.Word_31.setGeometry(QRect(470, 339, 101, 21))
        self.Word_31.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_31 = QLineEdit(uploading_windows)
        self.Meaning_31.setObjectName(u"Meaning_31")
        self.Meaning_31.setGeometry(QRect(610, 340, 251, 21))
        self.Meaning_31.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_32 = QLineEdit(uploading_windows)
        self.Word_32.setObjectName(u"Word_32")
        self.Word_32.setGeometry(QRect(470, 369, 101, 21))
        self.Word_32.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_32 = QLineEdit(uploading_windows)
        self.Meaning_32.setObjectName(u"Meaning_32")
        self.Meaning_32.setGeometry(QRect(610, 370, 251, 21))
        self.Meaning_32.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_33 = QLineEdit(uploading_windows)
        self.Meaning_33.setObjectName(u"Meaning_33")
        self.Meaning_33.setGeometry(QRect(610, 401, 251, 21))
        self.Meaning_33.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_33 = QLineEdit(uploading_windows)
        self.Word_33.setObjectName(u"Word_33")
        self.Word_33.setGeometry(QRect(470, 400, 101, 21))
        self.Word_33.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_34 = QLineEdit(uploading_windows)
        self.Meaning_34.setObjectName(u"Meaning_34")
        self.Meaning_34.setGeometry(QRect(610, 431, 251, 21))
        self.Meaning_34.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_34 = QLineEdit(uploading_windows)
        self.Word_34.setObjectName(u"Word_34")
        self.Word_34.setGeometry(QRect(470, 430, 101, 21))
        self.Word_34.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_35 = QLineEdit(uploading_windows)
        self.Word_35.setObjectName(u"Word_35")
        self.Word_35.setGeometry(QRect(470, 459, 101, 21))
        self.Word_35.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_35 = QLineEdit(uploading_windows)
        self.Meaning_35.setObjectName(u"Meaning_35")
        self.Meaning_35.setGeometry(QRect(610, 460, 251, 21))
        self.Meaning_35.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_36 = QLineEdit(uploading_windows)
        self.Meaning_36.setObjectName(u"Meaning_36")
        self.Meaning_36.setGeometry(QRect(610, 491, 251, 21))
        self.Meaning_36.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_36 = QLineEdit(uploading_windows)
        self.Word_36.setObjectName(u"Word_36")
        self.Word_36.setGeometry(QRect(470, 490, 101, 21))
        self.Word_36.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_37 = QLineEdit(uploading_windows)
        self.Word_37.setObjectName(u"Word_37")
        self.Word_37.setGeometry(QRect(470, 519, 101, 21))
        self.Word_37.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_37 = QLineEdit(uploading_windows)
        self.Meaning_37.setObjectName(u"Meaning_37")
        self.Meaning_37.setGeometry(QRect(610, 520, 251, 21))
        self.Meaning_37.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_38 = QLineEdit(uploading_windows)
        self.Meaning_38.setObjectName(u"Meaning_38")
        self.Meaning_38.setGeometry(QRect(610, 551, 251, 21))
        self.Meaning_38.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_38 = QLineEdit(uploading_windows)
        self.Word_38.setObjectName(u"Word_38")
        self.Word_38.setGeometry(QRect(470, 550, 101, 21))
        self.Word_38.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_39 = QLineEdit(uploading_windows)
        self.Meaning_39.setObjectName(u"Meaning_39")
        self.Meaning_39.setGeometry(QRect(610, 581, 251, 21))
        self.Meaning_39.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_39 = QLineEdit(uploading_windows)
        self.Word_39.setObjectName(u"Word_39")
        self.Word_39.setGeometry(QRect(470, 580, 101, 21))
        self.Word_39.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Meaning_40 = QLineEdit(uploading_windows)
        self.Meaning_40.setObjectName(u"Meaning_40")
        self.Meaning_40.setGeometry(QRect(610, 611, 251, 21))
        self.Meaning_40.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.Word_40 = QLineEdit(uploading_windows)
        self.Word_40.setObjectName(u"Word_40")
        self.Word_40.setGeometry(QRect(470, 610, 101, 21))
        self.Word_40.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid black;\n"
"}\n"
"")
        self.timeout = QComboBox(uploading_windows)
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.addItem("")
        self.timeout.setObjectName(u"timeout")
        self.timeout.setGeometry(QRect(960, 450, 81, 41))
        self.timeout.setFont(font)
        self.label_46 = QLabel(uploading_windows)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setGeometry(QRect(870, 450, 101, 41))
        font3 = QFont()
        font3.setPointSize(14)
        self.label_46.setFont(font3)

        self.retranslateUi(uploading_windows)

        QMetaObject.connectSlotsByName(uploading_windows)
    # setupUi

    def retranslateUi(self, uploading_windows):
        uploading_windows.setWindowTitle(QCoreApplication.translate("uploading_windows", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("uploading_windows", u"1.", None))
        self.label_2.setText(QCoreApplication.translate("uploading_windows", u"2.", None))
        self.label_3.setText(QCoreApplication.translate("uploading_windows", u"3.", None))
        self.label_4.setText(QCoreApplication.translate("uploading_windows", u"4.", None))
        self.label_5.setText(QCoreApplication.translate("uploading_windows", u"5.", None))
        self.label_6.setText(QCoreApplication.translate("uploading_windows", u"6.", None))
        self.label_7.setText(QCoreApplication.translate("uploading_windows", u"7.", None))
        self.label_8.setText(QCoreApplication.translate("uploading_windows", u"8.", None))
        self.label_9.setText(QCoreApplication.translate("uploading_windows", u"9.", None))
        self.label_10.setText(QCoreApplication.translate("uploading_windows", u"10.", None))
        self.label_11.setText(QCoreApplication.translate("uploading_windows", u"11.", None))
        self.label_12.setText(QCoreApplication.translate("uploading_windows", u"12.", None))
        self.label_13.setText(QCoreApplication.translate("uploading_windows", u"13.", None))
        self.label_14.setText(QCoreApplication.translate("uploading_windows", u"17.", None))
        self.label_15.setText(QCoreApplication.translate("uploading_windows", u"16.", None))
        self.label_16.setText(QCoreApplication.translate("uploading_windows", u"15.", None))
        self.label_17.setText(QCoreApplication.translate("uploading_windows", u"14.", None))
        self.label_18.setText(QCoreApplication.translate("uploading_windows", u"18.", None))
        self.label_19.setText(QCoreApplication.translate("uploading_windows", u"19.", None))
        self.label_20.setText(QCoreApplication.translate("uploading_windows", u"20.", None))
        self.label_41.setText(QCoreApplication.translate("uploading_windows", u"\ub2e8\uc5b4", None))
        self.label_42.setText(QCoreApplication.translate("uploading_windows", u"\ub73b", None))
        self.label_21.setText(QCoreApplication.translate("uploading_windows", u"38.", None))
        self.label_22.setText(QCoreApplication.translate("uploading_windows", u"30.", None))
        self.label_23.setText(QCoreApplication.translate("uploading_windows", u"35.", None))
        self.label_24.setText(QCoreApplication.translate("uploading_windows", u"36.", None))
        self.label_25.setText(QCoreApplication.translate("uploading_windows", u"31.", None))
        self.label_26.setText(QCoreApplication.translate("uploading_windows", u"34.", None))
        self.label_27.setText(QCoreApplication.translate("uploading_windows", u"26.", None))
        self.label_28.setText(QCoreApplication.translate("uploading_windows", u"23.", None))
        self.label_43.setText(QCoreApplication.translate("uploading_windows", u"\ub73b", None))
        self.label_29.setText(QCoreApplication.translate("uploading_windows", u"29.", None))
        self.label_30.setText(QCoreApplication.translate("uploading_windows", u"25.", None))
        self.label_31.setText(QCoreApplication.translate("uploading_windows", u"24.", None))
        self.label_32.setText(QCoreApplication.translate("uploading_windows", u"37.", None))
        self.label_44.setText(QCoreApplication.translate("uploading_windows", u"\ub2e8\uc5b4", None))
        self.label_33.setText(QCoreApplication.translate("uploading_windows", u"21.", None))
        self.label_34.setText(QCoreApplication.translate("uploading_windows", u"32.", None))
        self.label_35.setText(QCoreApplication.translate("uploading_windows", u"28.", None))
        self.label_36.setText(QCoreApplication.translate("uploading_windows", u"33.", None))
        self.label_37.setText(QCoreApplication.translate("uploading_windows", u"27.", None))
        self.label_38.setText(QCoreApplication.translate("uploading_windows", u"39.", None))
        self.label_39.setText(QCoreApplication.translate("uploading_windows", u"40.", None))
        self.label_40.setText(QCoreApplication.translate("uploading_windows", u"22.", None))
        self.label_125.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_126.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_127.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_128.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_129.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_130.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_131.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_132.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_133.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_134.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_135.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_136.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_137.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_138.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_139.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_140.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_141.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_142.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_143.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_144.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_145.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_146.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_147.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_148.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_149.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_150.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_151.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_152.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_153.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_154.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_155.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_156.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_157.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_158.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_159.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_160.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_161.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_162.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_163.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.label_164.setText(QCoreApplication.translate("uploading_windows", u"->", None))
        self.upload.setText(QCoreApplication.translate("uploading_windows", u"\uacfc\uc81c \uc5c5\ub85c\ub4dc", None))
        self.Subject_select.setItemText(0, QCoreApplication.translate("uploading_windows", u"DAY1", None))
        self.Subject_select.setItemText(1, QCoreApplication.translate("uploading_windows", u"DAY2", None))
        self.Subject_select.setItemText(2, QCoreApplication.translate("uploading_windows", u"DAY3", None))
        self.Subject_select.setItemText(3, QCoreApplication.translate("uploading_windows", u"DAY4", None))
        self.Subject_select.setItemText(4, QCoreApplication.translate("uploading_windows", u"DAY5", None))
        self.Subject_select.setItemText(5, QCoreApplication.translate("uploading_windows", u"DAY6", None))
        self.Subject_select.setItemText(6, QCoreApplication.translate("uploading_windows", u"DAY7", None))
        self.Subject_select.setItemText(7, QCoreApplication.translate("uploading_windows", u"DAY8", None))
        self.Subject_select.setItemText(8, QCoreApplication.translate("uploading_windows", u"DAY9", None))

        self.label_45.setText(QCoreApplication.translate("uploading_windows", u"<\uacfc\uc81c\uc120\ud0dd>", None))
#if QT_CONFIG(tooltip)
        self.Word_1.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_2.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_3.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_4.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_5.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_6.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_7.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_8.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_9.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_10.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_11.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_12.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_13.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_14.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_15.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_16.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_17.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_18.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_19.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_20.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_1.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.Meaning_1.setText("")
#if QT_CONFIG(tooltip)
        self.Meaning_2.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_3.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_4.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_5.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_6.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_7.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_8.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_10.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_11.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_12.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_13.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_14.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_15.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_16.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_17.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_18.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_19.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_20.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_21.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_21.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_22.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_22.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_23.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_23.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_24.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_24.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_25.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_25.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_26.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_26.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_27.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_27.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_28.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_28.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_29.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_29.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_30.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_30.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_31.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_31.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_32.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_32.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_33.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_33.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_34.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_34.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_35.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_35.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_36.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_36.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_37.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_37.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_38.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_38.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_39.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_39.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Meaning_40.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4\uc758 \ub73b\uc744 \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>\ub2e8\uc5b4\uc758 \ub73b\uc774 \uc5ec\ub7ec\uac1c \uc77c\uacbd\uc6b0 &quot;,&quot; \ub85c \uad6c\ubd84 \ud569\ub2c8\ub2e4.</p><p>Ex.\uc0ac\uacfc,\ubc14\ub098\ub098,\ubc30</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.Word_40.setToolTip(QCoreApplication.translate("uploading_windows", u"<html><head/><body><p>\ub2e8\uc5b4 \ub97c \uc815\uc758 \ud569\ub2c8\ub2e4. </p><p>Ex. Apple</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.timeout.setItemText(0, QCoreApplication.translate("uploading_windows", u"10\ubd84", None))
        self.timeout.setItemText(1, QCoreApplication.translate("uploading_windows", u"15\ubd84", None))
        self.timeout.setItemText(2, QCoreApplication.translate("uploading_windows", u"20\ubd84", None))
        self.timeout.setItemText(3, QCoreApplication.translate("uploading_windows", u"25\ubd84", None))
        self.timeout.setItemText(4, QCoreApplication.translate("uploading_windows", u"30\ubd84", None))
        self.timeout.setItemText(5, QCoreApplication.translate("uploading_windows", u"35\ubd84", None))
        self.timeout.setItemText(6, QCoreApplication.translate("uploading_windows", u"40\ubd84", None))
        self.timeout.setItemText(7, QCoreApplication.translate("uploading_windows", u"45\ubd84", None))
        self.timeout.setItemText(8, QCoreApplication.translate("uploading_windows", u"50\ubd84", None))
        self.timeout.setItemText(9, QCoreApplication.translate("uploading_windows", u"55\ubd84", None))
        self.timeout.setItemText(10, QCoreApplication.translate("uploading_windows", u"60\ubd84", None))

        self.label_46.setText(QCoreApplication.translate("uploading_windows", u"\uc81c\ud55c\uc2dc\uac04 :", None))
    # retranslateUi

