

## NOTE
This controller is included MEGA2560 board+ 4 channel motor driver board+ PS2 wireless controller, which can drive 4pcs motor with encoder specially for Mecanum wheel robot. It can move forward, backward, left, right, turn, sidesway, etc. What's more, you can develop it secondly, the driver board reserve servos interface can control the robot arm, can control the self-driving robot after adding a gyroscope because it can drive encoder motor.
note:The new version of the driver board corresponds to the schematic diagram, pin 26 27 needs to be modified to A4 A5


## CH340Driver installation
###
1.Download the Windows CH340 Driver.

2.Unzip the file.

3.Run the installer which you unzipped.

4.In the Arduino IDE when the CH340 is connected you will see a COM Port in the Tools > Serial Port menu, the COM number for your device may vary depending on your system.

### Change the mega2560 diver sch and motor encoder interface:exchange 5V GND position
![Encoder interface](https://github.com/MoebiusTech/MecanumRobot-ArduinoMega2560/blob/master/Motor%20interface.png
 "Encoder interface")
## 
If you have any problems, please contact us: Whatsapp:+86 13699824373; Email: moebius@mbeus.com
